#!/usr/bin/env python3
"""
MIDI parser script.

Uses music21 to analyze MIDI files and extract chord progressions.
"""

import re
import tarfile
import gzip
import requests
from typing import Dict, Optional
from pathlib import Path
import sys

# Add the parent directory to sys.path so we can import from db
sys.path.append(str(Path(__file__).parent.parent))

from db.queries import (
    get_pending_songs, update_song_midi_status, insert_section
)

# Try to import music21, handle gracefully if not available
try:
    from music21 import converter
    MUSIC21_AVAILABLE = True
except ImportError:
    MUSIC21_AVAILABLE = False
    print("Warning: music21 not available. MIDI parsing will be skipped.")


LAKH_URL = "http://hog.ee.columbia.edu/craffel/lmd/clean_midi.tar.gz"


def clean_title(title: str) -> str:
    """Clean title by removing Lakh version suffixes and other noise."""
    title = re.sub(r'\.\d+$', '', title).strip()
    title = re.sub(r'\s*\(live[^)]*\)', '', title, flags=re.I).strip()
    return title


def stream_extract_midi(url: str, lakh_path: str) -> Optional[bytes]:
    """Stream tar.gz and extract a specific MIDI file."""
    try:
        response = requests.get(url, stream=True)
        response.raise_for_status()
        
        gz_stream = gzip.GzipFile(fileobj=response.raw)
        tar = tarfile.open(fileobj=gz_stream, mode='r|')
        
        for member in tar:
            if member.name == lakh_path and member.isfile():
                return tar.extractfile(member).read()
        
        return None
    except Exception as e:
        print(f"Error streaming MIDI: {e}")
        return None


def analyze_midi(midi_data: bytes) -> Optional[Dict]:
    """Analyze MIDI data using music21 and extract chord information."""
    if not MUSIC21_AVAILABLE:
        return None
    
    try:
        # Load MIDI from bytes
        midi_stream = converter.parse(midi_data)
        
        # Detect key and mode
        key_analysis = midi_stream.analyze('key')
        key_name = str(key_analysis.tonic.name)
        mode = key_analysis.mode
        
        # Detect tempo
        tempo_analysis = midi_stream.metronomeMarkBoundaries()
        if tempo_analysis:
            bpm = tempo_analysis[0][2].number
        else:
            bpm = 120.0
        
        # Get measures and time signature
        measures = list(midi_stream.parts[0].getElementsByClass('Measure'))
        if not measures:
            return None
        
        # Analyze sections (simplified: 8-bar chunks)
        sections = []
        section_duration = 8 * 4  # 8 measures at 4 beats per measure
        
        for i, measure in enumerate(measures):
            if i % section_duration == 0:
                section_start = i * 4  # Convert measures to quarter notes
                section_measures = measures[i:i+section_duration]
                
                # Extract chords from this section
                section_stream = converter.stream.Stream()
                for m in section_measures:
                    section_stream.append(m)
                
                # Analyze chords in this section
                chords = []
                for element in section_stream.flat.getElementsByClass('Chord'):
                    if element.isConsonant():
                        # Convert to Harte notation (simplified)
                        harte_chord = convert_to_harte(element)
                        if harte_chord:
                            chords.append(harte_chord)
                
                if chords:
                    sections.append({
                        'start_ms': section_start * 60000 / bpm,  # Convert to ms
                        'duration_ms': section_duration * 4 * 60000 / bpm,
                        'key': key_name,
                        'mode': mode,
                        'bpm': bpm,
                        'harte_chords': chords
                    })
        
        return {
            'sections': sections,
            'key': key_name,
            'mode': mode,
            'bpm': bpm
        }
    
    except Exception as e:
        print(f"Error analyzing MIDI: {e}")
        return None


def convert_to_harte(chord) -> Optional[str]:
    """Convert music21 chord to Harte notation."""
    try:
        # Get root note
        root = chord.root().name
        
        # Get intervals from root
        intervals = [p.intervalWithRoot(chord.root()).name for p in chord.pitches]
        
        # Determine quality based on intervals
        if 'M3' in intervals and 'P5' in intervals:
            quality = 'maj'
        elif 'm3' in intervals and 'P5' in intervals:
            quality = 'min'
        elif 'm3' in intervals and 'd5' in intervals:
            quality = 'dim'
        elif 'M3' in intervals and 'm7' in intervals:
            quality = '7'
        elif 'M3' in intervals and 'M7' in intervals:
            quality = 'maj7'
        elif 'm3' in intervals and 'm7' in intervals:
            quality = 'min7'
        elif 'P5' in intervals and 'M2' in intervals:
            quality = 'sus2'
        elif 'P5' in intervals and 'P4' in intervals:
            quality = 'sus4'
        elif 'P5' in intervals:
            quality = '5'
        else:
            return None
        
        return f"{root}:{quality}"
    
    except Exception:
        return None


def process_batch(batch_size: int = 10):
    """Process a batch of songs for MIDI parsing."""
    print(f"Parsing MIDI for up to {batch_size} songs...")
    
    pending_songs = get_pending_songs(batch_size)
    processed = 0
    
    for song in pending_songs:
        try:
            # Stream and extract MIDI
            midi_data = stream_extract_midi(LAKH_URL, song['lakh_path'])
            if not midi_data:
                update_song_midi_status(song['id'], 'failed')
                continue
            
            # Analyze MIDI
            analysis = analyze_midi(midi_data)
            if not analysis:
                update_song_midi_status(song['id'], 'failed')
                continue
            
            # Insert sections
            for i, section in enumerate(analysis['sections']):
                insert_section(
                    song_id=song['id'],
                    section_idx=i,
                    name=f"Section {i+1}",
                    start_ms=section['start_ms'],
                    duration_ms=section['duration_ms'],
                    key=section['key'],
                    mode=section['mode'],
                    bpm=section['bpm'],
                    harte_chords=section['harte_chords']
                )
            
            update_song_midi_status(song['id'], 'parsed')
            processed += 1
            
            if processed % 5 == 0:
                print(f"Processed {processed} songs...")
        
        except Exception as e:
            print(f"Error processing {song['artist']} - {song['title']}: {e}")
            update_song_midi_status(song['id'], 'failed')
            continue
    
    print(f"Completed processing {processed} songs")


def main():
    """Main MIDI parser function."""
    print("Starting MIDI parser...")
    
    if not MUSIC21_AVAILABLE:
        print("Skipping MIDI parsing - music21 not available")
        return
    
    try:
        process_batch()
        print("MIDI parsing complete!")
    except Exception as e:
        print(f"Error during MIDI parsing: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()