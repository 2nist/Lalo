#!/usr/bin/env python3
"""
Lakh Clean MIDI ingest script.

Streams the Lakh Clean MIDI tar.gz file and extracts file listings without
downloading the full 223MB archive to disk.
"""

import re
import tarfile
import gzip
import requests
from typing import List, Tuple, Set
from pathlib import Path
import sys

# Add the parent directory to sys.path so we can import from db
sys.path.append(str(Path(__file__).parent.parent))

from db.queries import insert_song


LAKH_URL = "http://hog.ee.columbia.edu/craffel/lmd/clean_midi.tar.gz"


def clean_title(title: str) -> str:
    """Clean title by removing Lakh version suffixes and other noise."""
    # Remove .N suffix (e.g., "Song Title.1" -> "Song Title")
    title = re.sub(r'\.\d+$', '', title).strip()
    # Remove live tags
    title = re.sub(r'\s*\(live[^)]*\)', '', title, flags=re.I).strip()
    return title


def stream_tar_listing(url: str) -> List[Tuple[str, str]]:
    """Stream tar.gz and extract file paths without downloading full archive."""
    print(f"Streaming tar listing from {url}...")
    
    response = requests.get(url, stream=True)
    response.raise_for_status()
    
    # Use gzip to decompress the stream
    gz_stream = gzip.GzipFile(fileobj=response.raw)
    
    # Use tarfile in streaming mode to read headers only
    tar = tarfile.open(fileobj=gz_stream, mode='r|')
    
    songs = []
    seen: Set[Tuple[str, str]] = set()
    
    for member in tar:
        if member.isfile() and member.name.endswith('.mid'):
            # Parse path: "Artist/Title.mid"
            path_parts = member.name.split('/')
            if len(path_parts) >= 2:
                artist = path_parts[-2]
                title = path_parts[-1].replace('.mid', '')
                
                # Clean title
                title_clean = clean_title(title)
                
                # Normalize for deduplication
                key = (artist.lower(), title_clean.lower())
                if key not in seen:
                    seen.add(key)
                    songs.append((artist, title, title_clean, member.name))
    
    print(f"Found {len(songs)} unique songs")
    return songs


def ingest_songs(songs: List[Tuple[str, str, str, str]]):
    """Insert songs into database."""
    print("Inserting songs into database...")
    
    for artist, title, title_clean, lakh_path in songs:
        try:
            insert_song(artist, title, title_clean, lakh_path)
        except Exception as e:
            print(f"Error inserting {artist} - {title}: {e}")
            continue
    
    print(f"Successfully inserted {len(songs)} songs")


def main():
    """Main ingest function."""
    print("Starting Lakh Clean MIDI ingest...")
    
    try:
        songs = stream_tar_listing(LAKH_URL)
        ingest_songs(songs)
        print("Ingest complete!")
    except Exception as e:
        print(f"Error during ingest: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()