#!/usr/bin/env python3
"""
Lyrics fetcher script.

Fetches lyrics from LRCLIB API for songs in the database.
"""

import re
import requests
import time
from typing import Tuple, Optional
from pathlib import Path
import sys

# Add the parent directory to sys.path so we can import from db
sys.path.append(str(Path(__file__).parent.parent))

from db.queries import (
    get_pending_lyrics, update_song_lyrics
)


LRCLIB_URL = "https://lrclib.net/api/get"


def clean_title(title: str) -> str:
    """Clean title by removing Lakh version suffixes and other noise."""
    # Remove .N suffix (e.g., "Song Title.1" -> "Song Title")
    title = re.sub(r'\.\d+$', '', title).strip()
    # Remove live tags
    title = re.sub(r'\s*\(live[^)]*\)', '', title, flags=re.I).strip()
    return title


def fetch_lyrics(artist: str, title_clean: str) -> Tuple[str, Optional[str], Optional[str], Optional[int]]:
    """Fetch lyrics from LRCLIB API."""
    try:
        resp = requests.get(
            LRCLIB_URL,
            params={'artist_name': artist, 'track_name': title_clean},
            timeout=8
        )
        
        if resp.status_code == 200:
            data = resp.json()
            if data.get('instrumental'):
                return 'instrumental', None, None, data.get('id')
            elif data.get('syncedLyrics'):
                return 'hit_synced', data['syncedLyrics'], data.get('plainLyrics'), data.get('id')
            elif data.get('plainLyrics'):
                return 'hit_plain', None, data['plainLyrics'], data.get('id')
            return 'miss', None, None, None
        return 'miss', None, None, None
    except Exception:
        return 'miss', None, None, None


def process_batch(batch_size: int = 100):
    """Process a batch of songs for lyrics fetching."""
    print(f"Fetching lyrics for up to {batch_size} songs...")
    
    pending_songs = get_pending_lyrics(batch_size)
    processed = 0
    
    for song in pending_songs:
        artist = song['artist']
        title_clean = song['title_clean']
        
        # Fetch lyrics
        status, synced, plain, lrclib_id = fetch_lyrics(artist, title_clean)
        
        # Update database
        update_song_lyrics(
            song['id'], lrclib_id, synced, plain, status
        )
        
        processed += 1
        
        # Rate limiting: ~20 req/s
        time.sleep(0.05)
        
        if processed % 20 == 0:
            print(f"Processed {processed} songs...")
    
    print(f"Completed processing {processed} songs")


def main():
    """Main lyrics fetcher function."""
    print("Starting lyrics fetcher...")
    
    try:
        process_batch()
        print("Lyrics fetch complete!")
    except Exception as e:
        print(f"Error during lyrics fetch: {e}")
        sys.exit(1)


if __name__ == "__main__":
    main()